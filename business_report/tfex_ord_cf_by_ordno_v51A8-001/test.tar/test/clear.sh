
rm ./log/* > /dev/null 2>&1
rm ./db/*  > /dev/null 2>&1
rm ./out/* > /dev/null 2>&1
